package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class UserProfile extends AppCompatActivity {

    ImageView usericon;
    Button back;
    TextView name, email, mobile_number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        Intent intent =getIntent();

        usericon = findViewById(R.id.usericon);
        name = findViewById(R.id.user_name);
        mobile_number = findViewById(R.id.user_mobile_number);
        email = findViewById(R.id.user_email);
        back = findViewById(R.id.home);

        usericon.setImageResource(intent.getIntExtra("user_icon",R.drawable.icon01_01));
        name.setText(intent.getStringExtra("name").toString());
        System.out.println(intent.getStringExtra("name"));
        email.setText(intent.getStringExtra("email"));
        mobile_number.setText(intent.getStringExtra("mobile_number").toString());

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(UserProfile.this, MainActivity.class);
                startActivity(intent);
            }
        });




    }
}
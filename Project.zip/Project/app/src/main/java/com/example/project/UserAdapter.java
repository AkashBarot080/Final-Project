package com.example.project;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class UserAdapter extends ArrayAdapter {


    DatabaseConnection connection;
    List<User> userlist;
    int layoutRes;
    private LayoutInflater inflater;
    public UserAdapter(Context context,List<User> user, int resources )
    {
        super(context, resources, user);
        this.userlist = user;
        inflater = LayoutInflater.from(context);
        this.layoutRes =resources;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(view==null)
        {
            view = inflater.inflate(layoutRes, null);
            viewHolder = new ViewHolder();
            viewHolder.name = view.findViewById(R.id.name);
            viewHolder.email = view.findViewById(R.id.email);
            viewHolder.user_icon = view.findViewById(R.id.userIcon);
            final User user = userlist.get(i);
            viewHolder.name.setText(user.getUser_name());
            viewHolder.email.setText(user.getUser_email());
            viewHolder.user_icon.setImageResource(user.getUser_icon());
            view.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) view.getTag();
        }
        return view;
    }
    private static class ViewHolder
    {
        private TextView email, name;
        private  ImageView user_icon;
    }
    public int RandomValue()
    {
        int Min = 01;
        int Max = 30;
        int random_int = (int)Math.floor(Math.random()*(Max-Min+1)+Min);
        return (random_int);
    }

}

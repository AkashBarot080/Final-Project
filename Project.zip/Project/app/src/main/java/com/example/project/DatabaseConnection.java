package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseConnection extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "User";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "User";
    private  static final String COLUMN_NAME = "user_name";
    private static final String COLUMN_ID = "user_id";
    private static final String COLUMN_EMAIL = "user_email";
    private static final String COLUMN_PHONE_NUMBER = "user_phone_number";
    private static final String COLUMN_USER_ICON ="user_icon";
    public DatabaseConnection(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "CREATE TABLE " + TABLE_NAME + "(" +
                COLUMN_ID + " INTEGER NOT NULL CONSTRAINT employee_pk PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME +" varchar(200) not null,"+
                COLUMN_EMAIL + " varchar(200) NOT NULL, " +
                COLUMN_PHONE_NUMBER + " varchar(200) NOT NULL, "+
                COLUMN_USER_ICON +" INTEGER NOT NULL)";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String sql = "DROP TABLE IF EXISTS " + TABLE_NAME + ";";
        sqLiteDatabase.execSQL(sql);
        onCreate(sqLiteDatabase);
    }
    boolean addUser(String user_name,String user_email, String user_phone_number, int user_icon) {

        // in order to insert items into database, we need a writable database
        // this method returns a SQLite database instance
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        // we need to define a contentValues instance
        ContentValues cv = new ContentValues();

        // the first argument of the put method is the column name and the second the value
        cv.put(COLUMN_NAME, user_name);
        cv.put(COLUMN_EMAIL, user_email);
        cv.put(COLUMN_PHONE_NUMBER, user_phone_number);
        cv.put(COLUMN_USER_ICON, user_icon);

        // the insert method returns row number if the insertion is successful and -1 if unsuccessful
        return sqLiteDatabase.insert(TABLE_NAME, null, cv) != -1;
//        return true;
    }

    Cursor getAllUser() {

        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    User getUser(int id) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return (User) sqLiteDatabase.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+COLUMN_ID+" =?",new String[]{String.valueOf(id)}, null);
    }

//    boolean updateUser(int id,String user_name, String user_email, String user_phone_number) {
//        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
//
//        ContentValues cv = new ContentValues();
//        cv.put(COLUMN_NAME, user_name);
//        cv.put(COLUMN_EMAIL, user_email);
//        cv.put(COLUMN_PHONE_NUMBER, user_phone_number);
//
//        // this method returns the number of rows affected
//        return sqLiteDatabase.update(TABLE_NAME, cv, COLUMN_ID + "=?", new String[]{String.valueOf(id)}) > 0;
//    }

    boolean deleteEmployee(int id) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        // the delete method returns the number of rows affected
        return sqLiteDatabase.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }
}

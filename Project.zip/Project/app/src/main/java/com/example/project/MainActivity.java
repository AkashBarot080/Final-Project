package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button adduser;
    ListView list;
    List<User> userList;
    DatabaseConnection connection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adduser = findViewById(R.id.addUser);
        list = findViewById(R.id.userlist);
        userList = new ArrayList<>();
        connection = new DatabaseConnection(this);
        loadUsers();
        adduser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddUser.class);
                startActivity(intent);
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                User user = userList.get(i);
                Intent intent = new Intent(MainActivity.this, UserProfile.class);
                intent.putExtra("name", user.getUser_name());
                intent.putExtra("email", user.getUser_email());
                intent.putExtra("mobile_number", user.getUser_phone_number());
                intent.putExtra("id", user.getUser_id());
                intent.putExtra("user_icon", user.getUser_icon());
                System.out.println(user.getUser_email()+""+user.getUser_name()+""+user.getUser_phone_number());
                startActivity(intent);
            }
        });

    }

    private void loadUsers() {
        Cursor cursor = connection.getAllUser();
        if(cursor.moveToFirst())
        {
            do{
                System.out.print(cursor.getString(1));
                userList.add(new User(cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4)
                        ));
            }while (cursor.moveToNext());
            cursor.close();

        }
        UserAdapter userAdapter = new UserAdapter(this,userList,R.layout.user);
        list.setAdapter(userAdapter);
    }
}
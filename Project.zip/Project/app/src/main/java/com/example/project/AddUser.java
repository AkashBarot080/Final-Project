package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class AddUser extends AppCompatActivity implements View.OnClickListener {

    EditText user_name, user_email, user_mobile_number;
    Button save;
    final String SiteKey = "6LfQMpYdAAAAAFxtQIEqlsEQSO9EwQlcDJS9uMhV";
    final String SecretKey = "6LfQMpYdAAAAAPuaievzG2Z8zHLBkZ2uP1rgu400";
    RequestQueue queue;
    DatabaseConnection connection;
    String TAG = AddUser.class.getSimpleName();
    int img[] = {R.drawable.icon01_01, R.drawable.icon01_02, R.drawable.icon01_03, R.drawable.icon01_04, R.drawable.icon01_05,
            R.drawable.icon01_06, R.drawable.icon01_07, R.drawable.icon01_08, R.drawable.icon01_09, R.drawable.icon01_10,
            R.drawable.icon01_11, R.drawable.icon01_12, R.drawable.icon01_13, R.drawable.icon01_14, R.drawable.icon01_15,
            R.drawable.icon01_16, R.drawable.icon01_17, R.drawable.icon01_18, R.drawable.icon01_19, R.drawable.icon01_20,
            R.drawable.icon01_21, R.drawable.icon01_22, R.drawable.icon01_23,R.drawable.icon01_24, R.drawable.icon01_25,
            R.drawable.icon01_26, R.drawable.icon01_27, R.drawable.icon01_28, R.drawable.icon01_29, R.drawable.icon01_30};
    String name,email, mobile_number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        user_name = findViewById(R.id.user_name);
        user_email = findViewById(R.id.user_email);
        user_mobile_number = findViewById(R.id.user_mobile_number);
        save = findViewById(R.id.submitUser);
        connection = new DatabaseConnection(this);
        save.setOnClickListener(this);
        queue = Volley.newRequestQueue(getApplicationContext());
    }

    @Override
    public void onClick(View view) {
        name = user_name.getText().toString().trim();
        email = user_email.getText().toString().trim();
        mobile_number = user_mobile_number.getText().toString().trim();
        if(name.isEmpty())
        {
            user_name.setError("Please enter user name");
            user_name.setText("");
            user_name.requestFocus();
        }
        else
        {
            if(email.isEmpty())
            {
                user_email.setError("Please enter email id");
                user_email.setText("");
                user_email.requestFocus();
            }
            else{

                if(mobile_number.isEmpty())
                {
                    user_mobile_number.setError("Please enter password");
                    user_mobile_number.setText("");
                    user_mobile_number.requestFocus();
                }
                else
                {
                    SafetyNet.getClient(this).verifyWithRecaptcha(SiteKey)
                            .addOnSuccessListener(this, new OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse>() {
                                @Override
                                public void onSuccess(SafetyNetApi.RecaptchaTokenResponse response) {
                                    if (!response.getTokenResult().isEmpty()) {
                                        handleSiteVerify(response.getTokenResult());
                                    }
                                }
                            })
                            .addOnFailureListener(this, new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    if (e instanceof ApiException) {
                                        ApiException apiException = (ApiException) e;
                                        Log.d(TAG, "Error message: " +
                                                CommonStatusCodes.getStatusCodeString(apiException.getStatusCode()));
                                    } else {
                                        Log.d(TAG, "Unknown type of error: " + e.getMessage());
                                    }
                                }
                            });
                }

            }

        }



    }
    protected  void handleSiteVerify(final String responseToken){
        //it is google recaptcha siteverify server
        //you can place your server url
        String url = "https://www.google.com/recaptcha/api/siteverify";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                   new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if(jsonObject.getBoolean("success")){

                                if(connection.addUser(name, email, mobile_number,img[RandomValue()]))
                                {
                                    Toast.makeText(getApplicationContext(), "User has been added", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(AddUser.this, MainActivity.class);
                                    startActivity(intent);
                                }

                            }
                            else{
                                Toast.makeText(getApplicationContext(),String.valueOf(jsonObject.getString("error-codes")),Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception ex) {
                            Log.d(TAG, "JSON exception: " + ex.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error message: " + error.getMessage());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params= new HashMap<>();
                params.put("secret", SecretKey);
                params.put("response", responseToken);
                return params;
            }
        };
        request.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }
    public int RandomValue()
    {
        int Min = 01;
        int Max = 30;
        int random_int = (int)Math.floor(Math.random()*(Max-Min+1)+Min);
        return (random_int);
    }

}
